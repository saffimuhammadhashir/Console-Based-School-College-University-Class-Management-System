#include <iostream>
#include "Notification.h"
/*Including "Notification.h" allows the 
current code file to access the functionality and implementation details of
 the Notification class, assuming it has been properly
  declared and defined in that header file.*/

